
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        # Open the turtle
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='turtlesim',
            output='screen'
        ),

        # GoToPose active
        Node(
            package='package',
            executable='go_to_pose_server',
            name='go_to_pose_server',
            output='screen',
            parameters=[{
                'linear_speed': 1.0,
                'angular_speed': 1.0,
            }]
        ),

        # reset
        Node(
            package='package',
            executable='reset_turtle_server',
            name='reset_turtle_server',
            output='screen'
        ),

        # sqare active
        Node(
            package='package',
            executable='square_action_server',
            name='square_action_server',
            output='screen'
        ),
    ])
