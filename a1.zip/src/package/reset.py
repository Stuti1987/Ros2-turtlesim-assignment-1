
import rclpy
from rclpy.node import Node
from turtlesim_msgs.srv import TeleportAbsolute, SetPen


class TeleportTurtle(Node):
    def __init__(self):
        super().__init__('teleport_turtle')

        self.teleport_client = self.create_client(
            TeleportAbsolute, '/turtle1/teleport_absolute'
        )

        self.pen_client = self.create_client(
            SetPen, '/turtle1/set_pen'
        )

        self.get_logger().info('Waiting for turtlesim services...')

        self.timer = self.create_timer(0.5, self.start_teleport)
        self.started = False

    def start_teleport(self):
        if self.started:
            return

        if not self.teleport_client.service_is_ready():
            return

        if not self.pen_client.service_is_ready():
            return

        self.started = True
        self.timer.cancel()

        # Lift the pen so teleportation does not draw a line.
        pen_request = SetPen.Request()
        pen_request.r = 0
        pen_request.g = 0
        pen_request.b = 0
        pen_request.width = 1
        pen_request.off = 1

        future = self.pen_client.call_async(pen_request)
        future.add_done_callback(self.pen_lifted)

    def pen_lifted(self, future):
        try:
            future.result()
        except Exception as e:
            self.get_logger().error(f'Could not lift pen: {e}')
            return

        # Teleport to the requested position and orientation.
        request = TeleportAbsolute.Request()
        request.x = 5.544445
        request.y = 5.544445
        request.theta = 0.0

        future = self.teleport_client.call_async(request)
        future.add_done_callback(self.teleported)

    def teleported(self, future):
        try:
            future.result()
            self.get_logger().info(
                'Turtle teleported to the center with pen lifted.'
            )
        except Exception as e:
            self.get_logger().error(f'Teleport failed: {e}')


def main():
    rclpy.init()
    node = TeleportTurtle()

    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

