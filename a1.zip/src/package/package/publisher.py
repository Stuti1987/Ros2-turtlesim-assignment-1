import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class Publisher(Node):
    def __init__(self):
        super().__init__('publisher')
        self.pub = self.create_publisher(TargetPose, 'target_pose', 10)
        self.timer = self.create_timer(1.0, self.publish_pose)

    def publish_pose(self):
        msg = TargetPose()
        msg.x = 1.0
        msg.y = 2.0
        msg.yaw = 0.5
        self.pub.publish(msg)
        self.get_logger().info(f'Published: x={msg.x}, y={msg.y}, yaw={msg.yaw}')


def main():
    rclpy.init()
    node = PosePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
