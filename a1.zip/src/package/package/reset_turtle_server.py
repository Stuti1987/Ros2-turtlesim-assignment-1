
import asyncio

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import ReentrantCallbackGroup

from std_srvs.srv import Empty
from turtlesim_msgs.srv import TeleportAbsolute, SetPen
from package_interfaces.srv import ResetTurtle


class ResetTurtleServer(Node):
    def __init__(self):
        super().__init__('reset_turtle_server')

        self.cb = ReentrantCallbackGroup()

        self.clear_client = self.create_client(
            Empty, '/clear', callback_group=self.cb
        )

        self.teleport_client = self.create_client(
            TeleportAbsolute,
            '/turtle1/teleport_absolute',
            callback_group=self.cb
        )

        self.pen_client = self.create_client(
            SetPen, '/turtle1/set_pen', callback_group=self.cb
        )

        self.reset_service = self.create_service(
            ResetTurtle,
            '/reset_turtle',
            self.reset_callback,
            callback_group=self.cb
        )

        self.get_logger().info('Reset turtle service ready')

    async def call_service(self, client, request):
        while rclpy.ok() and not client.service_is_ready():
            await asyncio.sleep(0.1)

        if not rclpy.ok():
            raise RuntimeError('ROS 2 is shutting down')

        future = client.call_async(request)
        return await future

    async def reset_callback(self, request, response):
        del request

        try:
            #erase pen marks
            await self.call_service(self.clear_client, Empty.Request())

            # stop drawing lines
            pen_request = SetPen.Request()
            pen_request.r = 0
            pen_request.g = 0
            pen_request.b = 0
            pen_request.width = 0 
            pen_request.off = 0

            await self.call_service(self.pen_client, pen_request)

            # teleport turtle
            teleport_request = TeleportAbsolute.Request()
            teleport_request.x = 5.544445
            teleport_request.y = 5.544445
            teleport_request.theta = 0.0

            await self.call_service(
                self.teleport_client, teleport_request
            )

            response.success = True
            response.message = (
                'Turtle reset to starting pose; trails cleared.'
            )

            self.get_logger().info(response.message)

        except Exception as e:
            response.success = False
            response.message = f'Reset failed: {e}'
            self.get_logger().error(response.message)

        return response


def main():
    rclpy.init()
    node = ResetTurtleServer()

    executor = MultiThreadedExecutor()
    executor.add_node(node)

    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
