
import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer, ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from package_interfaces.action import DrawSquare, GoToPose
from package_interfaces.msg import TargetPose
from package_interfaces.srv import ResetTurtle


class SquareActionServer(Node):

    def __init__(self):
        super().__init__('square_action_server')

        self.callback_group = ReentrantCallbackGroup()

        self.reset_client = self.create_client(
            ResetTurtle,
            '/reset_turtle',
            callback_group=self.callback_group
        )

        self.go_to_pose_client = ActionClient(
            self,
            GoToPose,
            '/go_to_pose',
            callback_group=self.callback_group
        )

        self.square_server = ActionServer(
            self,
            DrawSquare,
            '/draw_square',
            execute_callback=self.execute_callback,
            callback_group=self.callback_group
        )

        self.get_logger().info('DrawSquare action server ready')

    async def execute_callback(self, goal_handle):
        side = goal_handle.request.side_length

        result = DrawSquare.Result()

        if side <= 0.0:
            result.success = False
            result.message = '....do you want it to NOT move?'
            goal_handle.abort()
            return result

        center = 5.544445
        if side > 5.0:
            result.success = False
            result.message = 'the window is NOT big enough for this try a lower number'
            goal_handle.abort()
            return result

        self.get_logger().info(
            f'Request received: draw a square with side {side:.2f}'
        )


        if not self.reset_client.wait_for_service(timeout_sec=5.0):
            result.success = False
            result.message = 'Reset service /reset_turtle is unavailable.'
            goal_handle.abort()
            return result

        reset_request = ResetTurtle.Request()
        reset_future = self.reset_client.call_async(reset_request)
        await reset_future
        reset_response = reset_future.result()

        if reset_response is None or not reset_response.success:
            result.success = False
            result.message = 'Could not reset the turtle.'
            goal_handle.abort()
            return result

        
        if not self.go_to_pose_client.wait_for_server(timeout_sec=5.0):
            result.success = False
            result.message = 'GoToPose action server is unavailable.'
            goal_handle.abort()
            return result

  
        corners = [
            (center + side, center, 0.0),
            (center + side, center + side, math.pi / 2.0),
            (center, center + side, math.pi),
            (center, center, -math.pi / 2.0),
        ]

        for index, (x, y, yaw) in enumerate(corners, start=1):
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                result.success = False
                result.message = 'Square drawing was canceled.'
                return result

            feedback = DrawSquare.Feedback()
            feedback.current_side = index
            feedback.status = f'Drawing side {index} of 4'
            goal_handle.publish_feedback(feedback)

            self.get_logger().info(feedback.status)

            pose = TargetPose()
            pose.x = float(x)
            pose.y = float(y)
            pose.yaw = float(yaw)

            movement_goal = GoToPose.Goal()
            movement_goal.target = pose

            send_future = self.go_to_pose_client.send_goal_async(
                movement_goal
            )
            await send_future
            movement_handle = send_future.result()

            if movement_handle is None or not movement_handle.accepted:
                result.success = False
                result.message = f'GoToPose rejected side {index}.'
                goal_handle.abort()
                return result

            movement_result_future = movement_handle.get_result_async()
            await movement_result_future
            movement_result = movement_result_future.result()

            if movement_result is None or not movement_result.result.success:
                result.success = False
                result.message = f'Movement failed on side {index}.'
                goal_handle.abort()
                return result

        # if everything works TELL MEEEEE
        result.success = True
        result.message = 'Square drawn successfully.'
        goal_handle.succeed()

        self.get_logger().info(result.message)
        return result



def main(args=None):
    rclpy.init(args=args)
    node = SquareActionServer()

    executor = MultiThreadedExecutor()
    executor.add_node(node)

    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
