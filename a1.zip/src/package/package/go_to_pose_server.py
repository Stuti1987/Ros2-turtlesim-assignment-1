import math
import time
from turtlesim_msgs.srv import SetPen

import rclpy
from geometry_msgs.msg import Twist
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from turtlesim_msgs.msg import Pose


from turtlesim_msgs.msg import Pose
from package_interfaces.action import GoToPose
from package_interfaces.srv import SetSpeedLimit
from package_interfaces.msg import TargetPose

def normalize(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


class GoToPoseServer(Node):
    def __init__(self):
        super().__init__('go_to_pose_server')
        cb = ReentrantCallbackGroup()

        self.pose = None
        self.max_linear = 10.0
        self.max_angular = 10.0
        self.declare_parameter('linear_speed', 1.0)
        self.declare_parameter('angular_speed', 1.0)

        self.cmd_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.pose_sub = self.create_subscription(
            Pose, '/turtle1/pose', self.pose_cb, 10, callback_group=cb)

        self.action_server = ActionServer(
            self, GoToPose, 'go_to_pose',
            execute_callback=self.execute_cb,
            goal_callback=self.goal_cb,
            cancel_callback=self.cancel_cb,
            callback_group=cb)

        self.srv = self.create_service(
            SetSpeedLimit, 'set_speed_limit',
            self.set_speed_limit_cb, callback_group=cb)

        self.get_logger().info('GoToPose action server ready')
        self.pen_client = self.create_client(SetPen, '/turtle1/set_pen')
        linear_speed = self.get_parameter('linear_speed').value
        angular_speed = self.get_parameter('angular_speed').value

    def pose_cb(self, msg):
        self.pose = msg

    def goal_cb(self, goal_request):
        t = goal_request.target
        if self.pose is None:
            self.get_logger().warn('No turtle pose yet (is turtlesim running?), rejecting')
            return GoalResponse.REJECT
        if not (0.0 <= t.x <= 11.0 and 0.0 <= t.y <= 11.0):
            self.get_logger().warn('Target outside turtlesim window (0-11), rejecting')
            return GoalResponse.REJECT
        self.get_logger().info(f'Goal accepted: x={t.x}, y={t.y}, yaw={t.yaw}')
        return GoalResponse.ACCEPT

    def cancel_cb(self, goal_handle):
        self.get_logger().info('Cancel requested')
        return CancelResponse.ACCEPT

    def set_speed_limit_cb(self, request, response):
        if request.max_linear <= 0.0 or request.max_angular <= 0.0:
            response.success = False
            response.message = 'Limits must be positive'
        else:
            self.max_linear = request.max_linear
            self.max_angular = request.max_angular
            response.success = True
            response.message = 'Speed limits updated'
        return response

    def stop(self):
        self.cmd_pub.publish(Twist())

    def execute_cb(self, goal_handle):
        target = goal_handle.request.target
        feedback = GoToPose.Feedback()
        result = GoToPose.Result()
        
        # Make sure the turtle's pen is enabled
        while not self.pen_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for set_pen service...')

        pen_request = SetPen.Request()
        pen_request.r = 255
        pen_request.g = 255
        pen_request.b = 255
        pen_request.width = 2
        pen_request.off = 0

        # Enable the turtle's pen before moving
        if not self.pen_client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error('Pen service is unavailable')
            goal_handle.abort()
            return result

        pen_request = SetPen.Request()
        pen_request.r = 255
        pen_request.g = 0
        pen_request.b = 0
        pen_request.width = 5
        pen_request.off = 0

        pen_future = self.pen_client.call_async(pen_request)

        while not pen_future.done():
            import time
            time.sleep(0.01)

        pen_response = pen_future.result()

        while rclpy.ok():
            p = self.pose
            dx = target.x - p.x
            dy = target.y - p.y
            distance = math.hypot(dx, dy)
            cmd = Twist()

            if goal_handle.is_cancel_requested:
                self.stop()
                goal_handle.canceled()
                result.success = False
                result.final_distance_error = distance
                return result

            if distance > 0.1:
                # Phase 1: drive to (x, y)
                heading_err = normalize(math.atan2(dy, dx) - p.theta)
                cmd.angular.z = max(-self.max_angular,
                                    min(self.max_angular, 4.0 * heading_err))
                if abs(heading_err) < 0.5:
                    cmd.linear.x = min(self.max_linear, 1.5 * distance)
            else:
                # Phase 2: rotate to final yaw
                yaw_err = normalize(target.yaw - p.theta)
                if abs(yaw_err) < 0.02:
                    break
                cmd.angular.z = max(-self.max_angular,
                                    min(self.max_angular, 4.0 * yaw_err))

            self.cmd_pub.publish(cmd)
            feedback.remaining_distance = distance
            goal_handle.publish_feedback(feedback)
            time.sleep(0.05)

        self.stop()
        goal_handle.succeed()
        result.success = True
        result.final_distance_error = math.hypot(
            target.x - self.pose.x, target.y - self.pose.y)
        return result


def main():
    rclpy.init()
    node = GoToPoseServer()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    executor.spin()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
